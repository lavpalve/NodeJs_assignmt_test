const express = require('express');
const app = express();

const empServices = require('./../services/index.js');

module.export = ()=>{
    app.get('/employee', (req, res)=>{
        
    });
}